#! /bin/bash
/home/jiangao/confu-master/date-script/confu -fuzz 3 -classpath=/home/jiangao/github/JBench/benchmark-suite/testRace12/bin -tool=FT2 -noxml testRace.TestRace12