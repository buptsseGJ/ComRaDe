package cn.edu.thu.platform.match;

public interface MatchInterface {

	public abstract void matchFile();

}