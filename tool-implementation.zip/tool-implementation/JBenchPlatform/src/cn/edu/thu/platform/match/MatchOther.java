package cn.edu.thu.platform.match;

import java.util.HashSet;
import java.util.Set;

import cn.edu.thu.platform.entity.Race;
import cn.edu.thu.platform.entity.Report;
import cn.edu.thu.platform.entity.Reports;

public class MatchOther implements MatchInterface {

	public MatchOther() {
		System.out.println("Start other matching...");
	}

	@Override
	public void matchFile() {
		//it need be implemented, please refer to the MatchCalfuzzer.java class
	}
}
